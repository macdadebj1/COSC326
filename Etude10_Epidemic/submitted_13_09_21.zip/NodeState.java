package epidemic;

public enum NodeState{
    VULNERABLE,
    SICK,
    IMMUNE,
    UNINITIALIZED
        }