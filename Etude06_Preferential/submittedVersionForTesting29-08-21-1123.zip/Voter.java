package Preference;

import java.util.ArrayList;

class Voter {

    ArrayList<String> voteList = new ArrayList<>();
    int voteIndex = 0;

    /**
     * default constructor.
     * */
    public Voter(){}

}